# [Candy Crush](https://youtu.be/8yIKZQMGi0A)

- Coding Tutorial: https://youtu.be/8yIKZQMGi0A
- Demo: https://imkennyyip.github.io/candy-crush/

In this tutorial, you will learn to create Candy Crush using HTML, CSS, and JavaScript. You will learn to swap candy pieces, crush candy pieces, and generate new ones.

![candy-crush-preview](https://user-images.githubusercontent.com/78777681/163042549-09b7534e-2a3d-4649-aed5-07332e6e8a53.png)
